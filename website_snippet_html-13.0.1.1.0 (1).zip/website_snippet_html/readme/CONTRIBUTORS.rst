* `Adgensee <https://www.adgensee.com>`__:

  * Vincent Garcies
