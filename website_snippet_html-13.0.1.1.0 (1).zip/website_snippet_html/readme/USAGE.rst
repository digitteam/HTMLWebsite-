To use this module, you need to:

* Edit any web page.
* Go to **Insert Blocks > HTML**.
* Drag it anywhere.

You can use this snippet for writing HTML, CSS and JavaScript code.
