This module was written to extend the functionality of website to support
inserting custom html code on a web page.
